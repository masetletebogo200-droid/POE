const BUSINESS_EMAIL = "masetletebogo200@gmail.com";
const WHATSAPP_NUMBER = "27697558873"; 


function setupFormSubmission(formId) {
  const form = document.getElementById(formId);
  if (!form) return;

  form.addEventListener("submit", async function (e) {
    e.preventDefault(); 

    const formData = new FormData(form);
    const data = {};
    formData.forEach((value, key) => {
      if (value && value !== "0") data[key] = value;
    });

    if (Object.keys(data).length < 2) {
      alert("Please fill in the form before sending.");
      return;
    }

    const btn = form.querySelector("button[type='submit']");
    const originalText = btn.textContent;
    btn.textContent = "Sending...";
    btn.disabled = true;

    try {
     
      const formParams = new URLSearchParams();
      for (const key in data) {
        formParams.append(key, data[key]);
      }
      formParams.append("_subject", `New ${formId === "orderForm" ? "Order" : "Booking"} — Masetle Sound Empire`);
      formParams.append("_template", "table");
      formParams.append("_captcha", "false");

  
      const response = await fetch(
        `https://formsubmit.co/ajax/${BUSINESS_EMAIL}`,
        {
          method: "POST",
          headers: {
            "Content-Type": "application/x-www-form-urlencoded",
            Accept: "application/json",
          },
          body: formParams.toString(),
        }
      );

      const result = await response.json();

      if (result.success === "true" || response.ok) {
        showSuccessMessage(form, formId);
        form.reset();
      } else {
        throw new Error("Send failed");
      }
    } catch (err) {
      
      alert(
        "Email sending failed. We'll open WhatsApp so you can send us your details directly."
      );
      openWhatsAppWithData(data, formId);
    } finally {
      btn.textContent = originalText;
      btn.disabled = false;
    }
  });
}

function showSuccessMessage(form, formId) {
  const msg = document.createElement("div");
  msg.className = "success-message";
  msg.innerHTML =
    " Thank you! Your " +
    (formId === "orderForm" ? "order" : "booking") +
    " has been sent. We'll contact you soon.";
  form.parentNode.insertBefore(msg, form.nextSibling);
  msg.scrollIntoView({ behavior: "smooth", block: "center" });
  setTimeout(() => msg.remove(), 8000);
}

function buildWhatsAppText(data, formId) {
  let text = `*New ${formId === "orderForm" ? "Order" : "Booking"} — Masetle Sound Empire*%0A%0A`;

  const labels = {
    fullname: "Name",
    phone: "Phone",
    email: "Email",
    address: "Address",
    vehicle: "Vehicle",
    "install-type": "Installation Type",
    date: "Preferred Date",
    time: "Preferred Time",
    notes: "Notes",
    amplifier: "Amplifier (qty)",
    subwoofer: "Subwoofer (qty)",
    speakers: "Speakers (qty)",
    wiring: "Wiring Kit (qty)",
    box: "Custom Sub Box (qty)",
    capacitor: "Power Capacitor (qty)",
  };

  for (const key in data) {
    const label = labels[key] || key;
    text += `*${label}:* ${data[key]}%0A`;
  }
  return text;
}

function openWhatsAppWithData(data, formId) {
  const text = buildWhatsAppText(data, formId);
  window.open(`https://wa.me/${WHATSAPP_NUMBER}?text=${text}`, "_blank");
}

function setupWhatsAppFloat() {
  const float = document.querySelector(".whatsapp-float");
  if (!float) return;

  float.addEventListener("click", function (e) {
    e.preventDefault();
    const msg = encodeURIComponent(
      "Hi Masetle Sound Empire, I'd like to enquire about your sound equipment and installation services."
    );
    window.open(`https://wa.me/${WHATSAPP_NUMBER}?text=${msg}`, "_blank");
  });
}

const PRICES = {
  amplifier: 1500,
  subwoofer: 1200,
  speakers: 800,
  wiring: 450,
  box: 1000,
  capacitor: 600,
};

function setupOrderCalculator() {
  const orderForm = document.getElementById("orderForm");
  if (!orderForm) return;

  const totalDiv = document.createElement("div");
  totalDiv.id = "orderTotal";
  totalDiv.className = "order-total";
  totalDiv.innerHTML = "<strong>Estimated Total: R0</strong>";
  const button = orderForm.querySelector("button[type='submit']");
  orderForm.insertBefore(totalDiv, button);

  function recalc() {
    let total = 0;
    for (const item in PRICES) {
      const input = orderForm.querySelector(`input[name="${item}"]`);
      if (input) total += (parseInt(input.value) || 0) * PRICES[item];
    }
    totalDiv.innerHTML = `<strong>Estimated Total: R${total.toLocaleString("en-ZA")}</strong>`;
  }

  orderForm.querySelectorAll('input[type="number"]').forEach((inp) => {
    inp.addEventListener("input", recalc);
  });
  recalc();
}


function setupDateValidation() {
  const dateInput = document.querySelector('input[name="date"]');
  if (!dateInput) return;
  const today = new Date().toISOString().split("T")[0];
  dateInput.setAttribute("min", today);
}


document.addEventListener("DOMContentLoaded", function () {
  
  if (document.getElementById("orderForm")) setupFormSubmission("orderForm");
  if (document.getElementById("bookingForm")) setupFormSubmission("bookingForm");

  setupWhatsAppFloat();
  setupOrderCalculator();
  setupDateValidation();
});
