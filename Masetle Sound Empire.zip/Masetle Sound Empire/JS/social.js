const FACEBOOK_PAGE = "https://www.facebook.com/profile.php?id=YOUR_PAGE_ID";

const LIVE_SITE_URL = "https://masetlesoundempire.co.za"; 

const SITE_URL = LIVE_SITE_URL + "/order.html#shop-now"; 
const SITE_TITLE = "Masetle Sound Empire — Car Sound Systems";

function shareToFacebook() {
  const url = encodeURIComponent(SITE_URL);
  const quote = encodeURIComponent(
    "Check out Masetle Sound Empire — Quality car sound systems, subwoofers and professional installations in South Africa!"
  );
  window.open(
    `https://www.facebook.com/sharer/sharer.php?u=${url}&quote=${quote}`,
    "_blank",
    "width=600,height=400"
  );
}

function shareToWhatsApp() {
  const text = encodeURIComponent(
    `Check out Masetle Sound Empire — Quality car sound systems, subwoofers and installations. Order online here:\n${SITE_URL}`
  );
  window.open(`https://wa.me/?text=${text}`, "_blank");
}

function copyPageLink() {
  navigator.clipboard
    .writeText(SITE_URL)
    .then(() => alert("Shop link copied! Share it with friends."))
    .catch(() => alert("Could not copy the link."));
}

function followOnFacebook() {
  window.open(FACEBOOK_PAGE, "_blank");
}

document.addEventListener("DOMContentLoaded", function () {
  const shareFb = document.getElementById("shareFacebook");
  const followFb = document.getElementById("followFacebook");
  const shareWa = document.getElementById("shareWhatsApp");
  const copyBtn = document.getElementById("copyLink");

  if (shareFb) shareFb.addEventListener("click", shareToFacebook);
  if (followFb) followFb.addEventListener("click", followOnFacebook);
  if (shareWa) shareWa.addEventListener("click", shareToWhatsApp);
  if (copyBtn) copyBtn.addEventListener("click", copyPageLink);
});
